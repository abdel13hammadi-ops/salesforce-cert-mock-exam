# salesforce-cert-mock-exam
Salesforce Admin Mock Exam

## Admin Login Security

This project uses a custom sidebar and hides Streamlit's default page list. Regular users see only user pages and a single **Admin** link. Admin-only pages are shown only after the admin account unlocks admin mode from the Admin page. Direct access to admin pages is blocked by a page-level gate.

Add these values in Streamlit Cloud **Settings → Secrets**:

```toml
ADMIN_PASSWORD = "your-strong-admin-password"
ADMIN_EMAILS = "your-admin-email@example.com"
```

For multiple admins:

```toml
ADMIN_EMAILS = "admin1@example.com, admin2@example.com"
```

Do not commit real secrets or passwords to GitHub.
