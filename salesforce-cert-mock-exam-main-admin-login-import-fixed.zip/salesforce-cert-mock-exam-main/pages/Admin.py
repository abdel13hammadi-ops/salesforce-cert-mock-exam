import os
import sys
from pathlib import Path

ROOT_DIR = Path(__file__).resolve().parents[1]
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

import streamlit as st

from utils.access_control import render_admin_login_page

st.set_page_config(page_title="Admin", layout="wide")
render_admin_login_page()
